"use client"

import { useState, useCallback } from "react"
import { Box, AppBar, Toolbar, Typography, IconButton } from "@mui/material"
import { Menu as MenuIcon } from "@mui/icons-material"
import Sidebar from "../components/Sidebar"
import Dashboard from "../components/Dashboard"
import "../styles/layout.css"

export default function MaterialUISidebar() {
  const [selectedParent, setSelectedParent] = useState(null)
  const [selectedChild, setSelectedChild] = useState(null)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [sidebarExpanded, setSidebarExpanded] = useState(true)
  const [hasSearched, setHasSearched] = useState(false)

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen)
  }

  const handleSelectionChange = useCallback((parent: any, child: any) => {
    setSelectedParent(parent)
    setSelectedChild(child)
    // Reset search state when selections change
    setHasSearched(false)
  }, [])

  const handleSidebarToggle = useCallback((expanded: boolean) => {
    setSidebarExpanded(expanded)
  }, [])

  const handleSearchClick = useCallback((searched: boolean) => {
    setHasSearched(searched)
  }, [])

  return (
    <Box className="app-container">
      <AppBar className={`app-bar ${sidebarExpanded ? "app-bar-expanded" : "app-bar-collapsed"}`}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            className="mobile-menu-button"
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap component="div" className="app-bar-title">
            Product Dashboard
          </Typography>
        </Toolbar>
      </AppBar>

      <Sidebar
        mobileOpen={mobileOpen}
        onDrawerToggle={handleDrawerToggle}
        onSelectionChange={handleSelectionChange}
        onSidebarToggle={handleSidebarToggle}
        onSearchClick={handleSearchClick}
      />

      <Box
        component="main"
        className={`main-content ${sidebarExpanded ? "main-content-expanded" : "main-content-collapsed"}`}
      >
        <Dashboard
          selectedParent={selectedParent}
          selectedChild={selectedChild}
          sidebarExpanded={sidebarExpanded}
          hasSearched={hasSearched}
        />
      </Box>
    </Box>
  )
}
