"use client"

import { useState, useCallback } from "react"
import { Box, AppBar, Toolbar, Typography, IconButton, ThemeProvider, createTheme, CssBaseline } from "@mui/material"
import { Menu as MenuIcon } from "@mui/icons-material"
import Sidebar from "./components/Sidebar"
import Dashboard from "./components/Dashboard"
import "./styles/layout.css"

const theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#667eea",
    },
    secondary: {
      main: "#764ba2",
    },
    background: {
      default: "#f5f7fa",
    },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 700,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: "0 4px 20px rgba(0,0,0,0.08)",
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          textTransform: "none",
          fontWeight: 600,
        },
      },
    },
  },
})

export default function App() {
  const [selectedParent, setSelectedParent] = useState(null)
  const [selectedChild, setSelectedChild] = useState(null)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [sidebarExpanded, setSidebarExpanded] = useState(true)
  const [hasSearched, setHasSearched] = useState(false)

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen)
  }

  const handleSelectionChange = useCallback((parent: any, child: any) => {
    setSelectedParent(parent)
    setSelectedChild(child)
    // Reset search state when selections change
    setHasSearched(false)
  }, [])

  const handleSidebarToggle = useCallback((expanded: boolean) => {
    setSidebarExpanded(expanded)
  }, [])

  const handleSearchClick = useCallback((searched: boolean) => {
    setHasSearched(searched)
  }, [])

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box className="app-container">
        <AppBar className={`app-bar ${sidebarExpanded ? "app-bar-expanded" : "app-bar-collapsed"}`}>
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              edge="start"
              onClick={handleDrawerToggle}
              className="mobile-menu-button"
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" noWrap component="div" className="app-bar-title">
              Product Dashboard
            </Typography>
          </Toolbar>
        </AppBar>

        <Sidebar
          mobileOpen={mobileOpen}
          onDrawerToggle={handleDrawerToggle}
          onSelectionChange={handleSelectionChange}
          onSidebarToggle={handleSidebarToggle}
          onSearchClick={handleSearchClick}
        />

        <Box
          component="main"
          className={`main-content ${sidebarExpanded ? "main-content-expanded" : "main-content-collapsed"}`}
        >
          <Dashboard
            selectedParent={selectedParent}
            selectedChild={selectedChild}
            sidebarExpanded={sidebarExpanded}
            hasSearched={hasSearched}
          />
        </Box>
      </Box>
    </ThemeProvider>
  )
}
