"use client"

import { useState, useEffect } from "react"
import {
  Box,
  Drawer,
  Typography,
  Autocomplete,
  TextField,
  Avatar,
  IconButton,
  Tooltip,
  Collapse,
  Button,
} from "@mui/material"
import {
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  Search as SearchIcon,
} from "@mui/icons-material"
import "../styles/sidebar.css"

// Sample data structure
const parentData = [
  {
    id: 1,
    name: "Electronics",
    icon: "📱",
    color: "#2196F3",
    description: "Electronic devices and gadgets",
  },
  {
    id: 2,
    name: "Clothing",
    icon: "👕",
    color: "#9C27B0",
    description: "Fashion and apparel items",
  },
  {
    id: 3,
    name: "Home & Garden",
    icon: "🏠",
    color: "#4CAF50",
    description: "Home improvement and garden supplies",
  },
  {
    id: 4,
    name: "Sports",
    icon: "⚽",
    color: "#FF9800",
    description: "Sports equipment and accessories",
  },
]

const childData: { [key: number]: any[] } = {
  1: [
    { id: 11, name: "Smartphones", price: "$699", stock: 45, rating: 4.5 },
    { id: 12, name: "Laptops", price: "$1299", stock: 23, rating: 4.7 },
    { id: 13, name: "Headphones", price: "$199", stock: 67, rating: 4.3 },
    { id: 14, name: "Tablets", price: "$499", stock: 34, rating: 4.4 },
  ],
  2: [
    { id: 21, name: "T-Shirts", price: "$29", stock: 120, rating: 4.2 },
    { id: 22, name: "Jeans", price: "$79", stock: 85, rating: 4.6 },
    { id: 23, name: "Sneakers", price: "$129", stock: 56, rating: 4.8 },
    { id: 24, name: "Jackets", price: "$159", stock: 42, rating: 4.4 },
  ],
  3: [
    { id: 31, name: "Garden Tools", price: "$89", stock: 78, rating: 4.3 },
    { id: 32, name: "Furniture", price: "$599", stock: 15, rating: 4.5 },
    { id: 33, name: "Lighting", price: "$149", stock: 92, rating: 4.1 },
    { id: 34, name: "Decor", price: "$39", stock: 156, rating: 4.0 },
  ],
  4: [
    { id: 41, name: "Basketball", price: "$49", stock: 67, rating: 4.6 },
    { id: 42, name: "Tennis Racket", price: "$199", stock: 34, rating: 4.7 },
    { id: 43, name: "Running Shoes", price: "$149", stock: 89, rating: 4.8 },
    { id: 44, name: "Yoga Mat", price: "$29", stock: 123, rating: 4.2 },
  ],
}

const drawerWidthExpanded = 320
const drawerWidthCollapsed = 80

interface SidebarProps {
  mobileOpen: boolean
  onDrawerToggle: () => void
  onSelectionChange: (parent: any, child: any) => void
  onSidebarToggle: (expanded: boolean) => void
  onSearchClick: (hasSearched: boolean) => void
}

export default function Sidebar({
  mobileOpen,
  onDrawerToggle,
  onSelectionChange,
  onSidebarToggle,
  onSearchClick,
}: SidebarProps) {
  const [selectedParent, setSelectedParent] = useState<any>(null)
  const [selectedChild, setSelectedChild] = useState<any>(null)
  const [availableChildren, setAvailableChildren] = useState<any[]>([])
  const [sidebarExpanded, setSidebarExpanded] = useState(true)

  const currentDrawerWidth = sidebarExpanded ? drawerWidthExpanded : drawerWidthCollapsed

  useEffect(() => {
    if (selectedParent) {
      setAvailableChildren(childData[selectedParent.id] || [])
      setSelectedChild(null)
    } else {
      setAvailableChildren([])
      setSelectedChild(null)
    }
  }, [selectedParent])

  useEffect(() => {
    onSelectionChange(selectedParent, selectedChild)
  }, [selectedParent, selectedChild, onSelectionChange])

  const handleSidebarToggle = () => {
    const newExpanded = !sidebarExpanded
    setSidebarExpanded(newExpanded)
    onSidebarToggle(newExpanded)
  }

  const handleSearchClick = () => {
    onSearchClick(true)
  }

  const drawer = (
    <div className="sidebar-container">
      {/* Header with toggle button */}
      <div className={`sidebar-header ${sidebarExpanded ? "sidebar-header-expanded" : "sidebar-header-collapsed"}`}>
        <Collapse in={sidebarExpanded} orientation="horizontal">
          <Typography className="sidebar-title">🎯 Smart Filter</Typography>
        </Collapse>
        <Tooltip title={sidebarExpanded ? "Collapse Sidebar" : "Expand Sidebar"} placement="right">
          <IconButton onClick={handleSidebarToggle} className="sidebar-toggle-button">
            {sidebarExpanded ? <ChevronLeftIcon /> : <ChevronRightIcon />}
          </IconButton>
        </Tooltip>
      </div>

      {/* Main content area */}
      <div className={`sidebar-content ${sidebarExpanded ? "sidebar-content-expanded" : "sidebar-content-collapsed"}`}>
        <Collapse in={sidebarExpanded}>
          <div>
            <div className="sidebar-section">
              <Typography className="sidebar-label">Select Category</Typography>
              <Autocomplete
                className="sidebar-autocomplete"
                options={parentData}
                getOptionLabel={(option) => option.name}
                value={selectedParent}
                onChange={(event, newValue) => setSelectedParent(newValue)}
                renderInput={(params) => (
                  <TextField {...params} placeholder="Choose a category..." variant="outlined" />
                )}
                renderOption={(props, option) => {
                  const { key, ...otherProps } = props
                  return (
                    <Box component="li" key={key} {...otherProps} className="sidebar-option">
                      <Avatar sx={{ bgcolor: option.color }} className="sidebar-option-avatar">
                        {option.icon}
                      </Avatar>
                      <Typography className="sidebar-option-text">{option.name}</Typography>
                    </Box>
                  )
                }}
              />
            </div>

            <div className="sidebar-section">
              <Typography className="sidebar-label">Select Product</Typography>
              <Autocomplete
                className={`sidebar-autocomplete ${!selectedParent ? "sidebar-autocomplete-disabled" : ""}`}
                options={availableChildren}
                getOptionLabel={(option) => option.name}
                value={selectedChild}
                onChange={(event, newValue) => setSelectedChild(newValue)}
                disabled={!selectedParent}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    placeholder={selectedParent ? "Choose a product..." : "Select category first"}
                    variant="outlined"
                  />
                )}
                renderOption={(props, option) => {
                  const { key, ...otherProps } = props
                  return (
                    <Box component="li" key={key} {...otherProps} className="sidebar-product-option">
                      <Typography className="sidebar-product-text">{option.name}</Typography>
                    </Box>
                  )
                }}
              />
            </div>
          </div>
        </Collapse>
      </div>

      {/* Search button at bottom - only show when expanded */}
      <Collapse in={sidebarExpanded}>
        <div className="sidebar-search-container">
          <Button
            variant="contained"
            startIcon={<SearchIcon />}
            onClick={handleSearchClick}
            className="sidebar-search-button"
          >
            Search
          </Button>
        </div>
      </Collapse>
    </div>
  )

  return (
    <Box
      component="nav"
      className={`sidebar-nav ${sidebarExpanded ? "sidebar-nav-expanded" : "sidebar-nav-collapsed"}`}
    >
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={onDrawerToggle}
        ModalProps={{ keepMounted: true }}
        className="drawer-temporary"
        PaperProps={{ className: "drawer-paper", style: { width: drawerWidthExpanded } }}
      >
        {drawer}
      </Drawer>
      <Drawer
        variant="permanent"
        className="drawer-permanent"
        PaperProps={{ className: "drawer-paper", style: { width: currentDrawerWidth } }}
        open
      >
        {drawer}
      </Drawer>
    </Box>
  )
}
