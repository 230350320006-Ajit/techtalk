import { Box, Typography, Paper } from "@mui/material"
import "../styles/dashboard.css"

interface DashboardProps {
  selectedParent: any
  selectedChild: any
  sidebarExpanded?: boolean
  hasSearched: boolean
}

export default function Dashboard({
  selectedParent,
  selectedChild,
  sidebarExpanded = true,
  hasSearched,
}: DashboardProps) {
  // Only show dashboard content when search is clicked AND BOTH selections are made
  if (hasSearched && selectedParent && selectedChild) {
    return (
      <Box className="dashboard-content-area">
        <Paper className="dashboard-results">
          <Typography variant="h5" className="dashboard-results-title">
            Selected Items
          </Typography>

          <Box className="dashboard-selection-item">
            <Typography variant="subtitle1" className="dashboard-selection-label">
              Category:
            </Typography>
            <Typography variant="h6" className="dashboard-selection-value">
              {selectedParent.name}
            </Typography>
          </Box>

          <Box className="dashboard-selection-item">
            <Typography variant="subtitle1" className="dashboard-selection-label">
              Product:
            </Typography>
            <Typography variant="h6" className="dashboard-selection-value">
              {selectedChild.name}
            </Typography>
          </Box>
        </Paper>
      </Box>
    )
  }

  // Hide dashboard completely when search not clicked or both selections not made
  return <Box className="dashboard-hidden"></Box>
}
