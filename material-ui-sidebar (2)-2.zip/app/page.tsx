"use client"

import { useState, useCallback } from "react"
import { Menu as MenuIcon } from "@mui/icons-material"
import Sidebar from "../src/components/Sidebar"
import Dashboard from "../src/components/Dashboard"
import { AppGlobalStyles } from "../src/styles/globalStyles"
import {
  AppContainer,
  StyledAppBar,
  StyledToolbar,
  LogoContainer,
  LogoEagle,
  LogoText,
  MainContent,
  MobileMenuButton,
} from "../src/styles/layoutStyles"

export default function MaterialUISidebar() {
  const [selectedParent, setSelectedParent] = useState(null)
  const [selectedChild, setSelectedChild] = useState(null)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [sidebarExpanded, setSidebarExpanded] = useState(true)
  const [hasSearched, setHasSearched] = useState(false)

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen)
  }

  const handleSelectionChange = useCallback((parent: any, child: any) => {
    setSelectedParent(parent)
    setSelectedChild(child)
    setHasSearched(false)
  }, [])

  const handleSidebarToggle = useCallback((expanded: boolean) => {
    setSidebarExpanded(expanded)
  }, [])

  const handleSearchClick = useCallback((searched: boolean) => {
    setHasSearched(searched)
  }, [])

  return (
    <>
      <AppGlobalStyles />
      <AppContainer>
        <StyledAppBar sidebarExpanded={sidebarExpanded}>
          <StyledToolbar>
            <MobileMenuButton color="inherit" aria-label="open drawer" edge="start" onClick={handleDrawerToggle}>
              <MenuIcon />
            </MobileMenuButton>
            <LogoContainer>
              <LogoEagle>🦅</LogoEagle>
              <LogoText>First American</LogoText>
            </LogoContainer>
          </StyledToolbar>
        </StyledAppBar>

        <Sidebar
          mobileOpen={mobileOpen}
          onDrawerToggle={handleDrawerToggle}
          onSelectionChange={handleSelectionChange}
          onSidebarToggle={handleSidebarToggle}
          onSearchClick={handleSearchClick}
        />

        <MainContent sidebarExpanded={sidebarExpanded}>
          <Dashboard
            selectedParent={selectedParent}
            selectedChild={selectedChild}
            sidebarExpanded={sidebarExpanded}
            hasSearched={hasSearched}
          />
        </MainContent>
      </AppContainer>
    </>
  )
}
