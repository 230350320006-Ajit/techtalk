"use client"

import { useState, useCallback } from "react"
import { ThemeProvider, createTheme, CssBaseline } from "@mui/material"
import { Menu as MenuIcon } from "@mui/icons-material"
import Sidebar from "./components/Sidebar"
import Dashboard from "./components/Dashboard"
import { AppGlobalStyles } from "./styles/globalStyles"
import {
  AppContainer,
  StyledAppBar,
  StyledToolbar,
  LogoContainer,
  LogoEagle,
  LogoText,
  MainContent,
  MobileMenuButton,
} from "./styles/layoutStyles"

const theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#1e3a5f",
    },
    secondary: {
      main: "#c8d4e0",
    },
    background: {
      default: "#c8d4e0",
    },
  },
  typography: {
    fontFamily: '"Arial", "Helvetica", sans-serif',
    h4: {
      fontWeight: 700,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 4,
          textTransform: "none",
          fontWeight: 600,
        },
      },
    },
  },
})

export default function App() {
  const [selectedParent, setSelectedParent] = useState(null)
  const [selectedChild, setSelectedChild] = useState(null)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [sidebarExpanded, setSidebarExpanded] = useState(true)
  const [hasSearched, setHasSearched] = useState(false)

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen)
  }

  const handleSelectionChange = useCallback((parent: any, child: any) => {
    setSelectedParent(parent)
    setSelectedChild(child)
    setHasSearched(false)
  }, [])

  const handleSidebarToggle = useCallback((expanded: boolean) => {
    setSidebarExpanded(expanded)
  }, [])

  const handleSearchClick = useCallback((searched: boolean) => {
    setHasSearched(searched)
  }, [])

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AppGlobalStyles />
      <AppContainer>
        <StyledAppBar sidebarExpanded={sidebarExpanded}>
          <StyledToolbar>
            <MobileMenuButton color="inherit" aria-label="open drawer" edge="start" onClick={handleDrawerToggle}>
              <MenuIcon />
            </MobileMenuButton>
            <LogoContainer>
              <LogoEagle>🦅</LogoEagle>
              <LogoText>First American</LogoText>
            </LogoContainer>
          </StyledToolbar>
        </StyledAppBar>

        <Sidebar
          mobileOpen={mobileOpen}
          onDrawerToggle={handleDrawerToggle}
          onSelectionChange={handleSelectionChange}
          onSidebarToggle={handleSidebarToggle}
          onSearchClick={handleSearchClick}
        />

        <MainContent sidebarExpanded={sidebarExpanded}>
          <Dashboard
            selectedParent={selectedParent}
            selectedChild={selectedChild}
            sidebarExpanded={sidebarExpanded}
            hasSearched={hasSearched}
          />
        </MainContent>
      </AppContainer>
    </ThemeProvider>
  )
}
