import { styled } from "@mui/material/styles"
import { AppBar, Box, Toolbar, IconButton, Typography } from "@mui/material"

const noExpand = { shouldForwardProp: (prop: string) => prop !== "sidebarExpanded" }

export const AppContainer = styled(Box)({
  display: "flex",
  minHeight: "100vh",
  backgroundColor: "#c8d4e0",
})

export const StyledAppBar = styled(
  AppBar,
  noExpand,
)<{ sidebarExpanded?: boolean }>(({ sidebarExpanded }) => ({
  backgroundColor: "#1e3a5f !important",
  background: "#1e3a5f !important",
  backgroundImage: "none !important",
  boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1) !important",
  transition: "all 0.3s ease-in-out !important",
  position: "fixed !important",
  zIndex: 1200,

  "@media (min-width: 600px)": {
    width: sidebarExpanded ? "calc(100vw - 320px) !important" : "calc(100vw - 80px) !important",
    marginLeft: sidebarExpanded ? "320px !important" : "80px !important",
  },

  "@media (max-width: 600px)": {
    width: "100% !important",
    marginLeft: "0 !important",
  },
}))

export const StyledToolbar = styled(Toolbar)({
  padding: "16px 24px !important", // Changed from 8px to 16px to match sidebar
  minHeight: "64px !important",
  height: "64px !important", // Added fixed height
  backgroundColor: "#1e3a5f !important",
  background: "#1e3a5f !important",
  display: "flex !important",
  alignItems: "center !important",
})

export const LogoContainer = styled(Box)({
  display: "flex !important",
  alignItems: "center !important",
  gap: "16px !important",
})

export const LogoEagle = styled(Box)({
  fontSize: "32px !important",
  color: "white !important",
  display: "flex !important",
  alignItems: "center !important",
  justifyContent: "center !important",
  width: "40px !important",
  height: "40px !important",
  backgroundColor: "rgba(255, 255, 255, 0.1) !important",
  borderRadius: "50% !important",
})

export const LogoText = styled("span")({
  color: "white !important",
  fontWeight: "400 !important",
  fontSize: "1.8rem !important",
  fontFamily: '"Arial", sans-serif !important',
  letterSpacing: "0.5px !important",
})

export const AppBarTitle = styled(Typography)({
  color: "white !important",
  fontWeight: "bold !important",
  fontSize: "1.25rem !important",
  fontFamily: '"Arial", sans-serif !important',
})

export const MainContent = styled(
  Box,
  noExpand,
)<{ sidebarExpanded?: boolean }>(({ sidebarExpanded }) => ({
  flexGrow: 1,
  padding: "0 !important",
  marginTop: "64px !important",
  transition: "all 0.3s ease-in-out !important",
  minHeight: "calc(100vh - 64px) !important",
  display: "flex !important",
  alignItems: "center !important",
  justifyContent: "center !important",
  boxSizing: "border-box !important",
  backgroundColor: "#c8d4e0 !important",

  "@media (min-width: 600px)": {
    marginLeft: sidebarExpanded ? "320px !important" : "80px !important",
    width: sidebarExpanded ? "calc(100vw - 320px) !important" : "calc(100vw - 80px) !important",
  },

  "@media (max-width: 600px)": {
    marginLeft: "0 !important",
    width: "100vw !important",
  },
}))

export const MobileMenuButton = styled(IconButton)({
  marginRight: "16px !important",
  color: "inherit",

  "@media (min-width: 600px)": {
    display: "none !important",
  },
})
