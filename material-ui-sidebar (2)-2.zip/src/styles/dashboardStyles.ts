import { styled } from "@mui/material/styles"
import { Box, Paper, Typography } from "@mui/material"

export const DashboardContentArea = styled(Box)({
  width: "100% !important",
  height: "100% !important",
  minHeight: "calc(100vh - 64px) !important",
  display: "flex !important",
  flexDirection: "column !important",
  alignItems: "stretch !important",
  justifyContent: "center !important",
  boxSizing: "border-box !important",
  padding: "24px !important",
  backgroundColor: "#c8d4e0 !important",
})

export const DashboardHidden = styled(Box)({
  width: "100% !important",
  height: "100% !important",
  minHeight: "calc(100vh - 64px) !important",
  backgroundColor: "#c8d4e0 !important",
  border: "none !important",
  boxShadow: "none !important",
})

export const DashboardResults = styled(Paper)({
  padding: "32px !important",
  borderRadius: "8px !important",
  boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1) !important",
  backgroundColor: "white !important",
  width: "100% !important",
  maxWidth: "none !important",
  margin: "0 !important",
  flex: "1 !important",
  border: "1px solid #ddd !important",
})

export const DashboardResultsTitle = styled(Typography)({
  fontWeight: "600 !important",
  color: "#1e3a5f !important",
  marginBottom: "24px !important",
  textAlign: "center !important",
  borderBottom: "2px solid #c8d4e0 !important",
  paddingBottom: "16px !important",
  fontFamily: '"Arial", sans-serif !important',
})

export const DashboardSelectionItem = styled(Box)({
  marginBottom: "20px !important",
  padding: "16px !important",
  backgroundColor: "#f8f9fa !important",
  borderRadius: "4px !important",
  borderLeft: "4px solid #1e3a5f !important",
  border: "1px solid #e9ecef !important",

  "&:last-child": {
    marginBottom: "0 !important",
  },
})

export const DashboardSelectionLabel = styled(Typography)({
  fontWeight: "600 !important",
  color: "#1e3a5f !important",
  marginBottom: "4px !important",
  fontSize: "0.9rem !important",
  fontFamily: '"Arial", sans-serif !important',
})

export const DashboardSelectionValue = styled(Typography)({
  fontWeight: "400 !important",
  color: "#333 !important",
  fontSize: "1.1rem !important",
  fontFamily: '"Arial", sans-serif !important',
})
