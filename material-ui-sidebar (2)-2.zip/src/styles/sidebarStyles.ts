import { styled } from "@mui/material/styles"
import { Box, Drawer, Typography, Button, IconButton } from "@mui/material"

const noExpand = { shouldForwardProp: (prop: string) => prop !== "expanded" }

export const SidebarContainer = styled(Box)({
  height: "100% !important",
  backgroundColor: "#1e3a5f !important",
  background: "#1e3a5f !important",
  backgroundImage: "none !important",
  transition: "all 0.3s ease-in-out !important",
  overflow: "hidden !important",
  display: "flex !important",
  flexDirection: "column !important",
})

export const SidebarHeader = styled(
  Box,
  noExpand,
)<{ expanded?: boolean }>(({ expanded }) => ({
  display: "flex !important",
  alignItems: "center !important",
  minHeight: "64px !important", // Changed from 80px to match AppBar
  height: "64px !important", // Added fixed height
  transition: "all 0.3s ease-in-out !important",
  backgroundColor: "#1e3a5f !important",
  background: "#1e3a5f !important",
  borderBottom: "1px solid rgba(255, 255, 255, 0.1) !important",
  padding: expanded ? "16px 24px !important" : "16px 8px !important", // Adjusted padding
  justifyContent: expanded ? "space-between !important" : "center !important",
}))

export const SidebarTitle = styled(Typography)({
  color: "white !important",
  fontWeight: "600 !important",
  fontSize: "1.2rem !important",
  fontFamily: '"Arial", sans-serif !important',
})

export const SidebarToggleButton = styled(IconButton)({
  color: "white !important",
  backgroundColor: "rgba(255, 255, 255, 0.1) !important",
  borderRadius: "4px !important",
  width: "36px !important",
  height: "36px !important",

  "&:hover": {
    backgroundColor: "rgba(255, 255, 255, 0.2) !important",
  },
})

export const SidebarContent = styled(
  Box,
  noExpand,
)<{ expanded?: boolean }>(({ expanded }) => ({
  flex: "1 !important",
  backgroundColor: "#c8d4e0 !important",
  background: "#c8d4e0 !important",
  paddingTop: "24px !important",
  padding: expanded ? "24px !important" : "8px !important",
}))

export const SidebarSection = styled(Box)({
  marginBottom: "24px !important",
})

export const SectionTitle = styled(Typography)({
  color: "#2c5aa0 !important", // Changed to dark sky blue
  fontWeight: "400 !important",
  fontSize: "0.85rem !important",
  fontFamily: '"Arial", sans-serif !important',
  marginBottom: "12px !important",
  textTransform: "uppercase !important",
  letterSpacing: "0.5px !important",
  opacity: "0.9 !important", // Slightly increased opacity for better visibility
})

export const SearchButton = styled(Button)({
  backgroundColor: "#1e3a5f !important",
  background: "#1e3a5f !important",
  backgroundImage: "none !important",
  color: "white !important",
  fontWeight: "600 !important",
  padding: "12px 24px !important",
  borderRadius: "8px !important", // Added border radius
  width: "100% !important",
  textTransform: "none !important",
  fontFamily: '"Arial", sans-serif !important',
  fontSize: "14px !important",

  "&:hover": {
    backgroundColor: "#2a4a6b !important",
    background: "#2a4a6b !important",
    backgroundImage: "none !important",
  },

  "&:active": {
    backgroundColor: "#1a3352 !important",
    background: "#1a3352 !important",
    backgroundImage: "none !important",
  },
})

export const SearchContainer = styled(Box)({
  padding: "24px !important",
  paddingTop: "0 !important",
  backgroundColor: "#c8d4e0 !important",
  background: "#c8d4e0 !important",
})

export const SidebarNav = styled(
  Box,
  noExpand,
)<{ expanded?: boolean }>(({ expanded }) => ({
  flexShrink: "0 !important",
  width: expanded ? "320px !important" : "80px !important",
  position: "fixed !important",
  top: "0 !important",
  left: "0 !important",
  height: "100vh !important",
  zIndex: 1100,
  transition: "width 0.3s ease-in-out !important",

  "@media (max-width: 600px)": {
    position: "relative !important",
    width: "0 !important",
    height: "auto !important",
  },
}))

export const StyledDrawer = styled(
  Drawer,
  noExpand,
)<{ expanded?: boolean }>(({ expanded }) => ({
  "& .MuiDrawer-paper": {
    boxSizing: "border-box !important",
    border: "none !important",
    transition: "width 0.3s ease-in-out !important",
    background: "#1e3a5f !important",
    backgroundColor: "#1e3a5f !important",
    width: expanded ? "320px" : "80px",
    position: "relative !important",
    height: "100vh !important",
  },

  "&.MuiDrawer-docked": {
    "& .MuiDrawer-paper": {
      position: "fixed !important",
      top: "0 !important",
      left: "0 !important",
      zIndex: 1100,
    },
  },
}))

export const AutocompleteStyles = {
  "& .MuiOutlinedInput-root": {
    backgroundColor: "white !important",
    background: "white !important",
    borderRadius: "8px !important", // Added border radius
    fontFamily: '"Arial", sans-serif !important',
    fontSize: "14px !important",

    "& fieldset": {
      borderColor: "#ccc !important",
      borderRadius: "8px !important", // Added border radius to fieldset
    },

    "&:hover fieldset": {
      borderColor: "#1e3a5f !important",
    },

    "&.Mui-focused fieldset": {
      borderColor: "#1e3a5f !important",
    },
  },

  "&.disabled .MuiOutlinedInput-root": {
    backgroundColor: "#f5f5f5 !important",
    background: "#f5f5f5 !important",
    borderRadius: "8px !important", // Added border radius for disabled state
  },

  // Add border radius to dropdown menu
  "& .MuiAutocomplete-popper": {
    "& .MuiPaper-root": {
      borderRadius: "8px !important",
      marginTop: "4px !important",
    },
  },
}

export const OptionContainer = styled(Box)({
  display: "flex !important",
  alignItems: "center !important",
  gap: "12px !important",
  padding: "8px 12px !important",
})

export const OptionText = styled(Typography)({
  fontWeight: "500 !important",
  fontSize: "14px !important",
  fontFamily: '"Arial", sans-serif !important',
})

export const ProductOptionContainer = styled(Box)({
  display: "flex !important",
  alignItems: "center !important",
  width: "100% !important",
  padding: "8px 12px !important",
})
