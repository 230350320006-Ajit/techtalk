import { GlobalStyles } from "@mui/material"

export const AppGlobalStyles = () => (
  <GlobalStyles
    styles={{
      "*": {
        boxSizing: "border-box",
        margin: 0,
        padding: 0,
      },
      "html, body": {
        height: "100%",
        fontFamily: '"Arial", "Helvetica", sans-serif',
      },
      "#root": {
        height: "100%",
      },
      body: {
        fontFamily: '"Arial", "Helvetica", sans-serif',
        backgroundColor: "#c8d4e0",
      },
    }}
  />
)
