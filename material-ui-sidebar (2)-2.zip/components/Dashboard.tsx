import {
  DashboardContentArea,
  DashboardHidden,
  DashboardResults,
  DashboardResultsTitle,
  DashboardSelectionItem,
  DashboardSelectionLabel,
  DashboardSelectionValue,
} from "../src/styles/dashboardStyles"

interface DashboardProps {
  selectedParent: any
  selectedChild: any
  sidebarExpanded?: boolean
  hasSearched: boolean
}

export default function Dashboard({
  selectedParent,
  selectedChild,
  sidebarExpanded = true,
  hasSearched,
}: DashboardProps) {
  // Only show dashboard content when search is clicked AND BOTH selections are made
  if (hasSearched && selectedParent && selectedChild) {
    return (
      <DashboardContentArea>
        <DashboardResults>
          <DashboardResultsTitle variant="h5">Selected Items</DashboardResultsTitle>

          <DashboardSelectionItem>
            <DashboardSelectionLabel variant="subtitle1">Category:</DashboardSelectionLabel>
            <DashboardSelectionValue variant="h6">{selectedParent.name}</DashboardSelectionValue>
          </DashboardSelectionItem>

          <DashboardSelectionItem>
            <DashboardSelectionLabel variant="subtitle1">Product:</DashboardSelectionLabel>
            <DashboardSelectionValue variant="h6">{selectedChild.name}</DashboardSelectionValue>
          </DashboardSelectionItem>
        </DashboardResults>
      </DashboardContentArea>
    )
  }

  // Hide dashboard completely when search not clicked or both selections not made
  return <DashboardHidden />
}
